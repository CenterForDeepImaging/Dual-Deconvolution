function SIM_image = SIM_image_from_Fkk(Fkk, otf_params)
    % Function to synthesize an SIM image from the matrix Fkk (frequency domain representation).
    % Input:
    %   - Fkk: Frequency domain matrix representing F(ko, ki).
    %   - otf_params: Structure containing OTF (Optical Transfer Function) parameters, 
    %                 including kin_mask and kout_mask.
    % Output:
    %   - SIM_image: Synthesized SIM image in the spatial domain.

disp('Synthesize SIM image from F(ko,ki) matrix ...');
precision = class(Fkk);

% Generate indexing information and convolution size for synthesis
% index_dk: Indices mapping each (ko, ki) pair to corresponding dk in the synthesized spectrum
% N_conv: Size of the convolution grid for the synthesized spectrum
[index_dk, N_conv] = index_for_synthesis(otf_params.kin_mask, otf_params.kout_mask);
num_of_dks = cast(N_conv, precision)^2;

% Reconstruct the SIM spectrum by accumulating Fkk values based on their corresponding indices
% Using a multi-threaded function (accumarray_mex_mt) for efficiency
SIM_spectrum = accumarray_mex_mt(index_dk, Fkk, num_of_dks);

% Convert the synthesized spectrum to an image in the spatial domain using inverse FFT
SIM_image = spectrum_to_image(SIM_spectrum);

disp('Done.');


