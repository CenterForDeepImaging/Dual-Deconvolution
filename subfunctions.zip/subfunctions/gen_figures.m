function fig = gen_figures(fig_number)

num_rows = 2;
num_cols = 3;
x_spacing = 0.02;
y_spacing = 0.06;

H = (1 - y_spacing*(num_rows+1))/num_rows;
yn = y_spacing:(H+y_spacing):(1-y_spacing);
yn = yn(1:num_rows);
W = (1 - x_spacing*(num_cols+1))/num_cols;
xn = x_spacing:(W+x_spacing):(1-x_spacing);
xn = xn(1:num_cols);
[blx, bly] = meshgrid(xn, flip(yn));

fig.handle = figure(fig_number);
pos = [0.02,0.2,0.62,0.6];

set(fig.handle, 'Units', 'normalized', 'Position', pos);
allAxesInFigure = findall(fig.handle,'type','axes');
delete(allAxesInFigure);

% figure for AO-2PSIM image
fig.AOSIM.axes = axes(fig.handle, 'Position',[blx(1,1), bly(1,1), W, H]);
fig.AOSIM.axes.CLimMode = 'auto';
fig.AOSIM.plot = imagesc([], 'Parent', fig.AOSIM.axes);
fig.AOSIM.axes.Visible = 'off';

% create figure for monitoring otf errors
fig.OTF_err.axes = axes(fig.handle, 'Position',[blx(2,1), bly(2,1), W, H]);
% fig.OTF_err.axes.XLim = [1 2];
fig.OTF_err.plot = plot(fig.OTF_err.axes, nan, nan, nan, nan);
ylabel(fig.OTF_err.axes, 'otf errors');
xlabel(fig.OTF_err.axes, 'iteration number');
fig.OTF_err.axes.Visible = 'off';

% figure for excitation phase transfer function, PTF_ex
fig.PTF_ex.axes = axes(fig.handle, 'Position',[blx(1,2), bly(1,2), W, H]);
fig.PTF_ex.axes.CLimMode = 'auto';
fig.PTF_ex.plot = imagesc([], 'Parent', fig.PTF_ex.axes);
fig.PTF_ex.axes.Visible = 'off';

% figure for monitoring emission phase transfer function, PTF_em
fig.PTF_em.axes = axes(fig.handle, 'Position',[blx(2,2), bly(2,2), W, H]);
fig.PTF_em.axes.CLimMode = 'auto';
fig.PTF_em.plot = imagesc([], 'Parent', fig.PTF_em.axes);
fig.PTF_em.axes.Visible = 'off';

% figure for monitoring excitation modulation transfer function, MTF_ex
fig.MTF_ex.axes = axes(fig.handle, 'Position',[blx(1,3), bly(1,3), W, H]);
fig.MTF_ex.axes.CLimMode = 'auto';
fig.MTF_ex.plot = imagesc([], 'Parent', fig.MTF_ex.axes);
fig.MTF_ex.axes.Visible = 'off';

% figure for monitoring emission modulation transfer function, MTF_em
fig.MTF_em.axes = axes(fig.handle, 'Position',[blx(2,3), bly(2,3), W, H]);
fig.MTF_em.axes.DataAspectRatio = [1 1 1];
fig.MTF_em.axes.CLimMode = 'auto';
fig.MTF_em.plot = imagesc([], 'Parent', fig.MTF_em.axes);
fig.MTF_em.axes.Visible = 'off';
