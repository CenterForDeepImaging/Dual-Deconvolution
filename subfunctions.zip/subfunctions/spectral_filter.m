function mask = spectral_filter(N_img, k_low, k_high, filter_type, precision)
% spectral_filter generates a spectral filter mask in the Fourier domain.
%
% Inputs:
%   - N_img: Size of the square image (number of pixels in one dimension, must be odd).
%   - k_low: Low-frequency cutoff value.
%   - k_high: High-frequency cutoff value.
%   - filter_type: Specifies the type of low-frequency filtering:
%                  0 - Ideal low-pass filter.
%                  1 - Exponential low-pass filter.
%   - precision: Data type of the output mask ('single', 'double', etc.).
%
% Outputs:
%   - mask: Flattened spectral filter mask, cast to the specified precision.
%
% The filter mask is constructed as a product of the low-frequency and 
% high-frequency components, designed to be applied in the Fourier domain.


[kx, ky] = meshgrid(1:N_img, 1:N_img);
kc = (N_img+1)/2;  % N_dk is always odd.
kr2 = (kx-kc).^2 + (ky-kc).^2;

if filter_type == 0
    low_mask = ((kx.^2 + ky.^2) >= k_low^2);
else
    low_mask = 1.0 - exp(-kr2/k_low^2);
end
high_mask = (kr2 <= k_high^2);

mask = low_mask.*high_mask;
mask = cast(mask(:), precision);

end
