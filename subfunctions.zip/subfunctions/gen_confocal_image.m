function confocal_image = gen_confocal_image(psim_data, pinhole_radius_in_um, precision)
    % This function creates a confocal two-photon fluorescence image by applying
    % a virtual pinhole to the camera image stack. The pinhole is defined as a
    % square region centered on the optical axis, with a radius specified in micrometers.
    %
    % Inputs:
    %   psim_data - A structure containing:
    %       cam_images  - A 3D stack of raw images acquired during scanning.
    %       otf_info    - A structure containing camera-specific parameters:
    %           N_cam - The number of pixels along one dimension of the camera.
    %       scan_info   - A structure containing scanning information, such as:
    %           pixel_pitch   - The pixel size in micrometers.
    %           N_scan_points - The number of scan points along one dimension.
    %   pinhole_radius_in_um - Radius of the virtual pinhole in micrometers.
    %   precision - The numeric precision to cast cam_images to ('single' or 'double').
    %
    % Outputs:
    %   confocal_image - A 2D confocal fluorescence image (N_scan_points x N_scan_points).
    %
    
disp('Generate confocal two-photon fluorescence image ...');

Nc = psim_data.otf_info.N_cam/2+1;
Nr = round(pinhole_radius_in_um/psim_data.scan_info.pixel_pitch);

pinhole_idx = (Nc-Nr):(Nc+Nr);

confocal_image = cast(psim_data.cam_images(pinhole_idx,pinhole_idx,:), precision);
confocal_image = squeeze(sum(sum(confocal_image,1),2));
confocal_image = reshape(confocal_image, psim_data.scan_info.N_scan_points, psim_data.scan_info.N_scan_points);

disp('Done.');
