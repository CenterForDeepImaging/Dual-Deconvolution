// ==========================================================
// indexing_array_mex_mt.cpp
//
// Copyright (c) 2024 Seokchan Yoon
// 
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT
//
// Description:
// Distributes elements of the input array 'Tkk' into the output array 'Tdkk' 
// based on subscripts specified in the 'index' array. Implements multithreading
// to parallelize the processing using C++ standard threads.
//
// Usage:
//    Tdkk = indexing_array_mex_mt(Tkk, index, m_dk, n_dk)
//
//  Inputs:
//    - Tkk: 3D image stack of size (N0 x N0 x N_images), where:
//           N0 is the size of an image along one direction, and N_images is the number of images.
//    - index: 1D uint64 array specifying the output positions for each element in Tkk.
//             MATLAB indexing is 1-based.
//    - m_dk: N0^2, the total number of pixels of one image in the Tkk stack.
//    - n_dk: Number of images in Tkk
//
//  Output:
//    - Tdkk: Output 2D array of size (m_dk x n_dk).
//
//  Compilation:
//   1. In MATLAB, set up a C++ compiler if not already done:
//      >> mex -setup C++
//   2. Compile this file using the following command in MATLAB:
//      >> mex -R2018a indexing_array_mex_mt.cpp
// ========================================================

#include "mex.h"
#include "matrix.h"
#include <math.h>
#include <thread>
#include <vector>

using std::thread;
using std::vector;

void errorChk(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void worker_csingle(mwSize, mwSize, mwSize*, mxComplexSingle*, mxComplexSingle*);
void worker_cdouble(mwSize, mwSize, mwSize*, mxComplexDouble*, mxComplexDouble*);
void worker_single(mwSize, mwSize, mwSize*, mxSingle*, mxSingle*);
void worker_double(mwSize, mwSize, mwSize*, mxDouble*, mxDouble*);

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
   //errorChk(nlhs, plhs, nrhs, prhs);
    
    mwSize len, i;
    mwSize *index = (mwSize *)mxGetUint64s(prhs[1]);  /* index array */
    mwSize num_of_index = mxGetM(prhs[1]);            /* length of index array */
    mwSize m_dk = (mwSize)mxGetScalar(prhs[2]);       /* number of rows of Tdkk */
    mwSize n_dk = (mwSize)mxGetScalar(prhs[3]);       /* number of columns of Tdkk */

    
    mwSize num_of_workers = (mwSize) std::thread::hardware_concurrency()/2;
    if(num_of_workers>num_of_index){
        num_of_workers = num_of_index;
    }
    
    vector<thread> workers;
    vector<mwSize> start_index;
    vector<mwSize> end_index;       
    
    len = num_of_index/num_of_workers;
    for (i = 0; i < (num_of_workers-1); i++)
    {
        start_index.push_back(i*len);
        end_index.push_back((i+1)*len-1);
    }
    start_index.push_back((num_of_workers-1)*len);
    end_index.push_back(num_of_index-1);
    
if( mxIsComplex(prhs[0]) )
    {
        if( mxIsSingle(prhs[0]) )
        {
            mxComplexSingle *Tkk, *Tdkk;
            Tkk = mxGetComplexSingles(prhs[0]);  /* pointer for input Tkk */
            plhs[0] = mxCreateNumericMatrix(m_dk, n_dk, mxSINGLE_CLASS, mxCOMPLEX); /* Create an nr_dk-by-nc_k mxArray  */
            Tdkk = mxGetComplexSingles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_csingle, start_index[i], end_index[i], index, Tkk, Tdkk));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();      
        }
        else
        {
            mxComplexDouble *Tkk, *Tdkk;
            Tkk = mxGetComplexDoubles(prhs[0]);
            plhs[0] = mxCreateNumericMatrix(m_dk, n_dk, mxDOUBLE_CLASS, mxCOMPLEX);
            Tdkk = mxGetComplexDoubles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_cdouble, start_index[i], end_index[i], index, Tkk, Tdkk));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();                     
        }
    }
    else
    {
        if( mxIsSingle(prhs[0]) )
        {
            mxSingle *Tkk, *Tdkk;
            Tkk = mxGetSingles(prhs[0]);  /* pointer for input Tkk */
            plhs[0] = mxCreateNumericMatrix(m_dk, n_dk, mxSINGLE_CLASS, mxREAL); /* Create an nr_dk-by-nc_k mxArray  */
            Tdkk = mxGetSingles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_single, start_index[i], end_index[i], index, Tkk, Tdkk));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();            
        }
        else
        {
            mxDouble *Tkk, *Tdkk;
            Tkk = mxGetDoubles(prhs[0]);
            plhs[0] = mxCreateNumericMatrix(m_dk, n_dk, mxDOUBLE_CLASS, mxREAL);
            Tdkk = mxGetDoubles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_double, start_index[i], end_index[i], index, Tkk, Tdkk));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();               
        }        
    }
}

void errorChk(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /* check for the proper number of arguments */
    if(nrhs != 4)
        mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:invalidNumInputs", "Four inputs required.");
    
    if(nlhs > 1)
        mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:maxlhs", "Too many output arguments.");
    
    if( !(mxIsDouble(prhs[0]) || mxIsSingle(prhs[0])) )
        mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:inputNotDoubleorSingleArray", "input array must be a double or single.");
        
    if( !mxIsUint64(prhs[1]) )
        mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:inputNot1DDoubleArray", "The input index must be an uint64 type array.");
    
    mwSize n, m, n_index, m_index, num_elms, num_of_index;    
    n = mxGetN(prhs[0]);                 /* number of columns of Tkk */
	m = mxGetM(prhs[0]);                 /* number of rows of Tkk */
    n_index = mxGetN(prhs[1]);           /* number of columns of index array */
    m_index = mxGetM(prhs[1]);           /* number of rows of index array */
            
    num_elms = n*m;
    num_of_index = n_index*m_index;
    if( num_elms != num_of_index )
        mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:inputIndexSizeDiff", "index array length must be the same as the number of elements of Tkk .");
    
    mwSize *index = (mwSize *)mxGetUint64s(prhs[1]);
    mwSize n_dk = mxGetN(prhs[0]);                     /* num of columns of Tdkk */
    mwSize m_dk = (mwSize)mxGetScalar(prhs[2]);        /* number of rows of Tdkk */    
    mwSize nmax = m_dk*n_dk;
    for (mwSize i = 0; i < num_of_index; i++){
        if( (index[i] == 0) || (index[i] > nmax) ){
            mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:indexOutofRange", "index exceeds valid range.");
        }
    }
}

void worker_csingle(mwSize start, mwSize end, mwSize* index, mxComplexSingle* Tkk, mxComplexSingle* Tdkk) 
{
    for (mwSize i = start; i <= end; i++)
        Tdkk[index[i]-1] = Tkk[i];
}
void worker_cdouble(mwSize start, mwSize end, mwSize* index, mxComplexDouble* Tkk, mxComplexDouble* Tdkk) 
{
    for (mwSize i = start; i <= end; i++)
        Tdkk[index[i]-1] = Tkk[i];
}
void worker_single(mwSize start, mwSize end, mwSize* index, mxSingle* Tkk, mxSingle* Tdkk) 
{
    for (mwSize i = start; i <= end; i++)
        Tdkk[index[i]-1] = Tkk[i];
}
void worker_double(mwSize start, mwSize end, mwSize* index, mxDouble* Tkk, mxDouble* Tdkk) 
{
    for (mwSize i = start; i <= end; i++)
        Tdkk[index[i]-1] = Tkk[i];
}
