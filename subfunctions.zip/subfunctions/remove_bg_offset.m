function psim_data = remove_bg_offset(psim_data, precision)
    % This function processes the cam_images field in the input psim_data
    % structure by:
    % 1. Subtracting the camera ADC offset and estimated DC background level.
    % 2. Correcting for any shift in the camera alignment.
    % 3. Ensuring all pixel intensity values are non-negative.
    %
    % Inputs:
    %   psim_data - A structure containing:
    %       cam_images - A 3D image stack to be processed. size of (N_cam x N_cam x N_cam^2)
    %   precision - The numeric precision to cast cam_images to ('single' or 'double').
    %
    % Outputs:
    %   psim_data - The input structure with cam_images field updated after:
    %       - Background subtraction.
    %       - Camera shift correction.

disp('Subtract camera ADC offset and background level ...');
% ----- remove DC background in camera images ----------
psim_data.cam_images = cast(psim_data.cam_images, precision);
[~, idx] = sort(squeeze(sum(sum(psim_data.cam_images,1),2)));
idx_num = fix(0.5*size(psim_data.cam_images,3));
aa = mean(psim_data.cam_images(:, :, idx(1:idx_num)), 3);
tmp = aa(1,:,:);
bg_level = mean(tmp(:));
tmp = aa(end,:,:);
bg_level = bg_level + mean(tmp(:));
tmp = aa(:,1,:);
bg_level = bg_level + mean(tmp(:));
tmp = aa(:,end,:);
bg_level = bg_level + mean(tmp(:));
bg_level = bg_level/4.0;

% ----- correct camera shift ------------------------------
max_sig = squeeze(max(max(psim_data.cam_images,[],1),[],2));
indx = find(max_sig>(2*bg_level));
mean_img = mean(psim_data.cam_images(:,:,indx),3);
[~, max_index] = max(mean_img(:));
[max_row, max_col] = ind2sub(size(mean_img), max_index);
shift_x =  max_col - double(psim_data.otf_info.N_cam/2+1); 
shift_y =  max_row - double(psim_data.otf_info.N_cam/2+1);
psim_data.cam_images = circshift(psim_data.cam_images, [-shift_y, -shift_x]);
% ----------------------------------------------------------

psim_data.cam_images = abs(psim_data.cam_images - bg_level);
psim_data.cam_images(psim_data.cam_images<0) = 0;
% ----------------------------------------------------------

disp('Done.');

