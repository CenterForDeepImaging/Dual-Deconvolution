function img = spectrum_to_image(spec)
    % Function to convert a spectrum (frequency domain) to an image (spatial domain)
    % using the inverse FFT.
    % 
    % Input:
    %   - spec: A 1D vector representing the synthesized spectrum.
    % Output:
    %   - img: A 2D image reconstructed in the spatial domain.    
    
% Calculate the size of the square matrix (N_dk x N_dk) from the 1D spectrum length.
% N_dk is derived from the square root of the number of elements in the spectrum.
% Note: N_dk is always odd, based on the expected properties of the spectrum.
N_dk = sqrt(size(spec,1));  % N_dk is always odd.

% Reshape the 1D spectrum into a 2D square matrix of size N_dk x N_dk.
spec = reshape(spec, N_dk, N_dk);

% Pad the spectrum with zeros to make its dimensions (N_dk+1) x (N_dk+1), 
% ensuring an even size for FFT computation.
% The padding is added to the top and left (pre-padding).
spec = padarray(spec, [1 1], 0, 'pre');

% Apply Fourier transforms to create the SIM image.
img = fftshift(spec);
img = ifft2(img);
img = fftshift(img);
img = abs(img);

end