// ==========================================================
// accumarray_mex_mt.cpp
//
// Copyright (c) 2024 Seokchan Yoon
// 
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT
//
// Discription:
// Multithreaded C++ version of MATLAB's accumarray function
// Constructs array A with accumulation.
//
// Usage: 
//   A = mex_accumarray_mt(indices, B, m_A)
//
// Inputs:
//   indices : int64 array specifying the indices of output array A.
//             The index value starts from 1 (MATLAB indexing convention).
//   B       : Input array having the same length as the number of indices.
//   m_A     : Length of the output 1D column vector A.
//
// Output:
//   A       : Accumulated 1D column vector of size [m_A x 1].
//
// Compilation:
//   1. In MATLAB, set up a C++ compiler if not already done:
//      >> mex -setup C++
//   2. Compile this file using the following command in MATLAB:
//      >> mex -R2018a accumarray_mex_mt.cpp
//
// Example:
//   indices = int64([1; 2; 1; 3]);
//   B = [10; 20; 30; 40];
//   m_A = 3;
//   A = mex_accumarray_mt(indices, B, m_A);
// ======================================================== 

#include "mex.h"
#include "matrix.h"
#include <math.h>
#include <thread>
#include <mutex>
#include <vector>

using std::thread;
using std::vector;
using std::mutex;
using std::lock_guard;

mutex mylock;

mwSize* index;
mwSize m_A;

void errorChk(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void worker_csingle(mwSize, mwSize, mxComplexSingle*, mxComplexSingle*);
void worker_cdouble(mwSize, mwSize, mxComplexDouble*, mxComplexDouble*);
void worker_single(mwSize, mwSize, mxSingle*, mxSingle*);
void worker_double(mwSize, mwSize, mxDouble*, mxDouble*);

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    //errorChk(nlhs, plhs, nrhs, prhs);
    
    mwSize num_of_index;
    mwSize ncol_index = mxGetN(prhs[0]);              /* number of rows of index array */
    mwSize nrow_index = mxGetM(prhs[0]);              /* number of rows of index array */
    
    m_A = (mwSize)mxGetScalar(prhs[2]);       /* length of A */
    index = (mwSize *)mxGetInt64s(prhs[0]);    /* index array */
    num_of_index = nrow_index*ncol_index;
    
    mwSize num_of_workers = (mwSize) std::thread::hardware_concurrency()/2;
    if(num_of_workers>num_of_index){
        num_of_workers = num_of_index;
    }
    
    vector<thread> workers;
    vector<mwSize> start_index;
    vector<mwSize> end_index;
    
    mwSize len = num_of_index/num_of_workers;
    for (mwSize i = 0; i < (num_of_workers-1); i++)
    {
        start_index.push_back(i*len);
        end_index.push_back((i+1)*len-1);
    }
    start_index.push_back((num_of_workers-1)*len);
    end_index.push_back(num_of_index-1);
    
    if( mxIsComplex(prhs[1]) )
    {
        if( mxIsSingle(prhs[1]) )
        {
            mxComplexSingle *A, *B;
            B = mxGetComplexSingles(prhs[1]);  /* pointer for input B */
            plhs[0] = mxCreateNumericMatrix(m_A, 1, mxSINGLE_CLASS, mxCOMPLEX); /* Create an m_A-sized mxArray  */
            A = mxGetComplexSingles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_csingle, start_index[i], end_index[i], A, B));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();
        }
        else
        {
            mxComplexDouble *A, *B;
            B = mxGetComplexDoubles(prhs[1]);
            plhs[0] = mxCreateNumericMatrix(m_A, 1, mxDOUBLE_CLASS, mxCOMPLEX);
            A = mxGetComplexDoubles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_cdouble, start_index[i], end_index[i], A, B));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();
        }
    }
    else
    {
        if( mxIsSingle(prhs[1]) )
        {
            mxSingle *A, *B;
            B = mxGetSingles(prhs[1]);  /* pointer for input Tkk */
            plhs[0] = mxCreateNumericMatrix(m_A, 1, mxSINGLE_CLASS, mxREAL); /* Create an nr_dk-by-nc_k mxArray  */
            A = mxGetSingles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_single, start_index[i], end_index[i], A, B));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();
        }
        else
        {
            mxDouble *A, *B;
            B = mxGetDoubles(prhs[1]);
            plhs[0] = mxCreateNumericMatrix(m_A, 1, mxDOUBLE_CLASS, mxREAL);
            A = mxGetDoubles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_double, start_index[i], end_index[i], A, B));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();
        }
    }
}


void errorChk(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /* check for the proper number of arguments */
    if(nrhs != 3)
        mexErrMsgIdAndTxt( "MATLAB:mex_accumarray_mt:invalidNumInputs", "three inputs required.");
    
    if(nlhs > 1)
        mexErrMsgIdAndTxt( "MATLAB:mex_accumarray_mt:maxlhs", "Too many output arguments.");
    
    if(!mxIsInt64(prhs[0]))
        mexErrMsgIdAndTxt( "MATLAB:mex_accumarray_mt:inputNotDoubleorSingleArray", "The Input index must be an Int64 column vector.");
    
    if( !(mxIsDouble(prhs[1]) || mxIsSingle(prhs[1])) )
        mexErrMsgIdAndTxt( "MATLAB:mex_accumarray_mt:inputNotDoubleorSingleArray", "input B must be a double or single.");
    
    mwSize m_A, n, m, n_index, m_index, num_elms, num_of_index;
    n_index = mxGetN(prhs[0]);       /* number of columns of index array */
    m_index = mxGetM(prhs[0]);       /* number of rows of index array */
    n = mxGetN(prhs[1]);           /* number of columns of B */
    m = mxGetM(prhs[1]);           /* number of rows of B */
    m_A = (mwIndex)mxGetScalar(prhs[2]);       /* length of A */
    mwSize *index = (mwSize *)mxGetInt64s(prhs[0]);
   
    if( (n_index != n) || (m_index != m) )
        mexErrMsgIdAndTxt( "MATLAB:mex_accumarray_mt:inputIndexSizeDiff", "The size of index array must be the same as the size of of B .");
    
    num_of_index = n_index*m_index;
    for (mwSize i = 0; i < num_of_index; i++){
        if( (index[i] <= 0) || (index[i] > m_A) ){
            mexErrMsgIdAndTxt( "MATLAB:mex_accumarray_mt:indexOutofRange", "index exceeds valid range.");
        }
    }
}

void worker_csingle(mwSize start, mwSize end, mxComplexSingle* A, mxComplexSingle* B)
{
    mxArray* local_Array = mxCreateNumericMatrix(m_A, 1, mxSINGLE_CLASS, mxCOMPLEX);
    volatile mxComplexSingle *A_local = mxGetComplexSingles(local_Array);
    for (mwSize i = start; i <= end; i++){
        A_local[index[i]-1].real += B[i].real;
        A_local[index[i]-1].imag += B[i].imag;
    }
    
    lock_guard<mutex> lock_guard(mylock);
    for (mwSize i = 0; i < m_A; i++){
        A[i].real += A_local[i].real;
        A[i].imag += A_local[i].imag;
    }
    mxDestroyArray(local_Array);
}
void worker_cdouble(mwSize start, mwSize end, mxComplexDouble* A, mxComplexDouble* B)
{
    mxArray* local_Array = mxCreateNumericMatrix(m_A, 1, mxDOUBLE_CLASS, mxCOMPLEX);
    mxComplexDouble *A_local = mxGetComplexDoubles(local_Array);
    
    for (mwSize i = start; i <= end; i++){
        A_local[index[i]-1].real += B[i].real;
        A_local[index[i]-1].imag += B[i].imag;
    }
    
    lock_guard<mutex> lock_guard(mylock);
    for (mwSize i = 0; i < m_A; i++){
        A[i].real += A_local[i].real;
        A[i].imag += A_local[i].imag;
    }
    mxDestroyArray(local_Array);
}
void worker_single(mwSize start, mwSize end, mxSingle* A, mxSingle* B)
{
    mxArray *local_Array = mxCreateNumericMatrix(m_A, 1, mxSINGLE_CLASS, mxREAL);
    volatile mxSingle *A_local = mxGetSingles(local_Array);
    
    for (mwSize i = start; i <= end; i++)
        A_local[index[i]-1] += B[i];
    
    lock_guard<mutex> lock_guard(mylock);
    for (mwSize i = 0; i < m_A; i++){
        A[i] += A_local[i];
    }
    mxDestroyArray(local_Array);
}
void worker_double(mwSize start, mwSize end, mxDouble* A, mxDouble* B)
{
    mxArray* local_Array = mxCreateNumericMatrix(m_A, 1, mxDOUBLE_CLASS, mxREAL);
    volatile mxDouble *A_local = mxGetDoubles(local_Array);
    
    for (mwSize i = start; i <= end; i++)
        A_local[index[i]-1] += B[i];
    
    lock_guard<mutex> lock_guard(mylock);
    for (mwSize i = 0; i < m_A; i++){
        A[i] += A_local[i];
    }
    mxDestroyArray(local_Array);
}







