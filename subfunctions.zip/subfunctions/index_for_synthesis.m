function [index_dk, N_dk] = index_for_synthesis(kin_mask, kout_mask)
%
% Copyright (c) 2024 Seokchan Yoon
% 
% This software is released under the MIT License.
% https://opensource.org/licenses/MIT
%
% Description:
% Function to compute the indices for synthesizing the SIM spectrum.
%
% Input:
%   - kin_mask: A 2D binary mask representing the input frequency components.
%   - kout_mask: A 2D binary mask representing the output frequency components.
%
% Output:
%   - index_dk: Linear indices mapping the (kout, kin) pairs to dk values.
%   - N_dk: Size of the grid for dk values (square matrix, N_dk x N_dk).

% Calculate the central index for the input (kin) and output (kout) masks, 
% assuming the mask size is odd, and the center corresponds to (N/2 + 1).
kin_c = size(kin_mask,1)/2 + 1;
kout_c = size(kout_mask,1)/2 + 1;

% Identify the non-zero elements in the masks, returning their row (y) and column (x) indices
[kin_y, kin_x] = find(kin_mask);
[kout_y, kout_x] = find(kout_mask);

% Shift the indices to make them relative to the center of the masks
kin_y = kin_y - kin_c;
kin_x = kin_x - kin_c;
kout_y = kout_y - kout_c;
kout_x = kout_x - kout_c;

% Compute dk values: dk = kout - kin for both x and y components
dk_y = kout_y + kin_y';
dk_x = kout_x + kin_x';

% Determine the range of dk values by finding the maximum and minimum values
max_dky = max(dk_y(:));
min_dky = min(dk_y(:));
max_dkx = max(dk_y(:));
min_dkx = min(dk_x(:));

% Calculate the maximum absolute dk value (dk_max) and the grid size (N_dk)
% N_dk is the size of the square grid and is always odd
dk_max = max([abs(max_dky), abs(min_dky), abs(max_dkx), abs(min_dkx)]);
N_dk = 2*dk_max + 1;

% Adjust dk indices to make them suitable for 1-based indexing
% Adding dk_max + 1 ensures that all indices are positive and within bounds
dk_y = dk_y + dk_max + 1;
dk_x = dk_x + dk_max + 1;

% Map the 2D (dk_y, dk_x) indices to linear indices using sub2ind
% This creates a linear mapping for efficient indexing
index_dk = int64(sub2ind([N_dk, N_dk], dk_y, dk_x));

end