// ==========================================================
// crop_array_mex_mt.cpp
//
// Copyright (c) 2024 Seokchan Yoon
// 
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT
//
// Description:
// Crops input array B: B(rs:re, cs:ce)
//
// Usage: A = mex_crop_array_mt(B, rs, re, cs, ce)
// Input:
//      B: 2D array or 3D stack
//      rs, re: start and end indices for rows
//      cs, ce: start and end indices for columns
// Output:
//      A: cropped 2D or 3D array, corresponding to B(rs:re, cs:ce)
//
//  Compilation:
//   1. In MATLAB, set up a C++ compiler if not already done:
//      >> mex -setup C++
//   2. Compile this file using the following command in MATLAB:
//      >> mex -R2018a crop_array_mex_mt.cpp
// ========================================================

#include "mex.h"
#include "matrix.h"
#include <math.h>
#include <thread>
#include <vector>

using std::thread;
using std::vector;

void errorChk(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void worker_csingle(mwSize, mwSize, mwSize, mwSize, const mwSize [], mwSize[], mxComplexSingle*, mxComplexSingle*);
void worker_cdouble(mwSize, mwSize, mwSize, mwSize, const mwSize [], mwSize[], mxComplexDouble*, mxComplexDouble*);
void worker_single(mwSize, mwSize, mwSize, mwSize, const mwSize [], mwSize[], mxSingle*, mxSingle*);
void worker_double(mwSize, mwSize, mwSize, mwSize, const mwSize [], mwSize[], mxDouble*, mxDouble*);


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    //errorChk(nlhs, plhs, nrhs, prhs);
    
    const mwSize *Dims;
    mwSize numOfDims;
    mwSize Dims_c[3];
    mwSize rs, re, cs, ce;
    mwSize M, N, L, Nc, Mc;
    mwSize len, num_of_workers;
    
    numOfDims = mxGetNumberOfDimensions(prhs[0]);
    Dims = mxGetDimensions(prhs[0]);
    M = Dims[0];                 /* number of rows in inArray */
    N = Dims[1];                 /* number of columns in inArray */
    L = 1;
    if(numOfDims==3) L = Dims[2];
    
    rs = (mwSize)mxGetScalar(prhs[1]) - 1;
    re = (mwSize)mxGetScalar(prhs[2]) - 1;
    cs = (mwSize)mxGetScalar(prhs[3]) - 1;
    ce = (mwSize)mxGetScalar(prhs[4]) - 1;
    
    Mc = re-rs+1;
    Nc = ce-cs+1;
    Dims_c[0] = Mc;          /* number of rows in crop array */
    Dims_c[1] = Nc;          /* number of columns in crop array */
    Dims_c[2] = L;
    
    num_of_workers = (mwSize) std::thread::hardware_concurrency()/2;
    if(num_of_workers>L)
        num_of_workers = L;
    
    vector<thread> workers;
    vector<mwSize> start_L;
    vector<mwSize> end_L;
    
    len = L/num_of_workers;
    for (mwSize i = 0; i < (num_of_workers-1); i++)
    {
        start_L.push_back(i*len);
        end_L.push_back((i+1)*len-1);
    }
    start_L.push_back((num_of_workers-1)*len);
    end_L.push_back(L-1);
    
    if( mxIsComplex(prhs[0]) )
    {
        if( mxIsSingle(prhs[0]) )
        {
            mxComplexSingle *B, *A;
            B = mxGetComplexSingles(prhs[0]);  /* pointer for input Tkk */
            if (Dims_c[2]==1)
                plhs[0] = mxCreateNumericMatrix(Dims_c[0], Dims_c[1], mxSINGLE_CLASS, mxCOMPLEX);
            else
                plhs[0] = mxCreateNumericArray(3, Dims_c, mxSINGLE_CLASS, mxCOMPLEX);
            A = mxGetComplexSingles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_csingle, start_L[i], end_L[i], rs, cs, Dims, Dims_c, B, A));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();
        }
        else
        {
            mxComplexDouble *B, *A;
            B = mxGetComplexDoubles(prhs[0]);
            if (Dims_c[2]==1)
                plhs[0] = mxCreateNumericMatrix(Dims_c[0], Dims_c[1], mxDOUBLE_CLASS, mxCOMPLEX);
            else
                plhs[0] = mxCreateNumericArray(3, Dims_c, mxDOUBLE_CLASS, mxCOMPLEX);
            A = mxGetComplexDoubles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_cdouble, start_L[i], end_L[i], rs, cs, Dims, Dims_c, B, A));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();
        }
    }
    else
    {
        if( mxIsSingle(prhs[0]) )
        {
            mxSingle *B, *A;
            B = mxGetSingles(prhs[0]);
            if (Dims_c[2]==1)
                plhs[0] = mxCreateNumericMatrix(Dims_c[0], Dims_c[1], mxSINGLE_CLASS, mxREAL);
            else
                plhs[0] = mxCreateNumericArray(3, Dims_c, mxSINGLE_CLASS, mxREAL);
            A = mxGetSingles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_single, start_L[i], end_L[i], rs, cs, Dims, Dims_c, B, A));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();
        }
        else
        {
            mxDouble *B, *A;
            B = mxGetDoubles(prhs[0]);
            if (Dims_c[2]==1)
                plhs[0] = mxCreateNumericMatrix(Dims_c[0], Dims_c[1], mxDOUBLE_CLASS, mxREAL);
            else
                plhs[0] = mxCreateNumericArray(3, Dims_c, mxDOUBLE_CLASS, mxREAL);
            A = mxGetDoubles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_double, start_L[i], end_L[i], rs, cs, Dims, Dims_c, B, A));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();
        }
    }
}


void errorChk(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    mwSize rs, re, cs, ce, numOfDims;
    const mwSize *Dims;
    
    /* check for the proper number of arguments */
    if(nrhs != 5)
        mexErrMsgIdAndTxt( "MATLAB:crop_3D_array:invalidNumInputs", "Five inputs required.");
    
    if(nlhs > 1)
        mexErrMsgIdAndTxt( "MATLAB:crop_3D_array:maxlhs", "Too many output arguments.");
    
    if( !(mxIsSingle(prhs[0])||mxIsDouble(prhs[0])) )
        mexErrMsgIdAndTxt( "MATLAB:crop_3D_array:inputNotFloatingPointNumbers", "Input must be a floating point array.");
    
    numOfDims = mxGetNumberOfDimensions(prhs[0]);
    if( numOfDims == 1 || numOfDims > 3)
        mexErrMsgIdAndTxt( "MATLAB:crop_3D_array:inputArrayDims", "Input array must be a 2D array or 3D matrix.");
    
    Dims = mxGetDimensions(prhs[0]);
    
    rs = (mwSize)mxGetScalar(prhs[1]);
    re = (mwSize)mxGetScalar(prhs[2]);
    cs = (mwSize)mxGetScalar(prhs[3]);
    ce = (mwSize)mxGetScalar(prhs[4]);
    
    if( rs<1 || rs>Dims[0] || re<rs || re>Dims[0] || cs<1 || cs>Dims[1] || ce<cs || ce>Dims[1] )
        mexErrMsgIdAndTxt( "MATLAB:crop_3D_array:cropIndexRange", "Crop index is out of range.");
}


void worker_csingle(mwSize start_L, mwSize end_L, mwSize rs, mwSize cs, const mwSize Dims[], mwSize Dims_c[], mxComplexSingle* B, mxComplexSingle* A)
{
    mwSize l, tmpl, tmpl_c, nc, n, tmpn, tmpn_c, mc, m;
    mwSize N, M, Nc, Mc;
    M = Dims[0];
    N = Dims[1];
    Mc = Dims_c[0];
    Nc = Dims_c[1];
    
    for (l = start_L; l<=end_L; l++ ){
        tmpl = l*(N*M);
        tmpl_c = l*(Nc*Mc);
        for ( nc = 0; nc < Nc; nc++){
            n = nc + cs;
            tmpn = n*M + tmpl;
            tmpn_c = nc*Mc + tmpl_c;
            for ( mc = 0; mc < Mc; mc++){
                m = mc+rs;
                A[mc+tmpn_c] = B[m+tmpn];
            }
        }
    }
}

void worker_cdouble(mwSize start_L, mwSize end_L, mwSize rs, mwSize cs, const mwSize Dims[], mwSize Dims_c[], mxComplexDouble* B, mxComplexDouble* A)
{
    mwSize l, tmpl, tmpl_c, nc, n, tmpn, tmpn_c, mc, m;
    mwSize N, M, Nc, Mc;
    M = Dims[0];
    N = Dims[1];
    Mc = Dims_c[0];
    Nc = Dims_c[1];
    
    for (l = start_L; l<=end_L; l++ ){
        tmpl = l*(N*M);
        tmpl_c = l*(Nc*Mc);
        for ( nc = 0; nc < Nc; nc++){
            n = nc + cs;
            tmpn = n*M + tmpl;
            tmpn_c = nc*Mc + tmpl_c;
            for ( mc = 0; mc < Mc; mc++){
                m = mc+rs;
                A[mc+tmpn_c] = B[m+tmpn];
            }
        }
    }
}

void worker_single(mwSize start_L, mwSize end_L, mwSize rs, mwSize cs, const mwSize Dims[], mwSize Dims_c[], mxSingle* B, mxSingle* A)
{
    mwSize l, tmpl, tmpl_c, nc, n, tmpn, tmpn_c, mc, m;
    mwSize N, M, Nc, Mc;
    M = Dims[0];
    N = Dims[1];
    Mc = Dims_c[0];
    Nc = Dims_c[1];
    
    for (l = start_L; l<=end_L; l++ ){
        tmpl = l*(N*M);
        tmpl_c = l*(Nc*Mc);
        for ( nc = 0; nc < Nc; nc++){
            n = nc + cs;
            tmpn = n*M + tmpl;
            tmpn_c = nc*Mc + tmpl_c;
            for ( mc = 0; mc < Mc; mc++){
                m = mc+rs;
                A[mc+tmpn_c] = B[m+tmpn];
            }
        }
    }
}

void worker_double(mwSize start_L, mwSize end_L, mwSize rs, mwSize cs, const mwSize Dims[], mwSize Dims_c[], mxDouble* B, mxDouble* A)
{
    mwSize l, tmpl, tmpl_c, nc, n, tmpn, tmpn_c, mc, m;
    mwSize N, M, Nc, Mc;
    M = Dims[0];
    N = Dims[1];
    Mc = Dims_c[0];
    Nc = Dims_c[1];
    
    for (l = start_L; l<=end_L; l++ ){
        tmpl = l*(N*M);
        tmpl_c = l*(Nc*Mc);
        for ( nc = 0; nc < Nc; nc++){
            n = nc + cs;
            tmpn = n*M + tmpl;
            tmpn_c = nc*Mc + tmpl_c;
            for ( mc = 0; mc < Mc; mc++){
                m = mc+rs;
                A[mc+tmpn_c] = B[m+tmpn];
            }
        }
    }
}


