// ==========================================================
// reconstruct_Fkk_mex.cpp
//
// Copyright (c) 2024 Seokchan Yoon
// 
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT
//
// Description:
// Constructs a 2D spectral response matrix Fkk using an input spectral image and index mapping.
//
// Usage: Fkk = reconstruct_Fkk_mex(spectrum, index_dk)
// Inputs:
//      spectrum: Input spectral image (can be a 1D or 2D array).
//      index_dk: An m-by-n matrix representing indexing information. Values start from 1 (Matlab indexing order).
// Outputs:
//      Fkk: An m-by-n sized 2D output array.
// ========================================================

#include "mex.h"
#include "matrix.h"
#include <math.h>
#include <thread>
#include <vector>

using std::thread;
using std::vector;

void errorChk(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]);
void worker_csingle(mwSize, mwSize, mwSize*, mxComplexSingle*, mxComplexSingle*);
void worker_cdouble(mwSize, mwSize, mwSize*, mxComplexDouble*, mxComplexDouble*);
void worker_single(mwSize, mwSize, mwSize*, mxSingle*, mxSingle*);
void worker_double(mwSize, mwSize, mwSize*, mxDouble*, mxDouble*);

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
   //errorChk(nlhs, plhs, nrhs, prhs);
    
    mwSize len, i, num_of_index;
    mwSize *index = (mwSize *)mxGetInt64s(prhs[1]);  /* index array */
    mwSize m_index = mxGetM(prhs[1]);       /* number of rows of index_dk */
    mwSize n_index = mxGetN(prhs[1]);       /* number of columns of index_dk */
    num_of_index = m_index*n_index;
        
    mwSize num_of_workers = (mwSize) std::thread::hardware_concurrency()/2;
    if(num_of_workers>num_of_index){
        num_of_workers = num_of_index;
    }
    
    vector<thread> workers;
    vector<mwSize> start_index;
    vector<mwSize> end_index;       
    
    len = num_of_index/num_of_workers;
    for (i = 0; i < (num_of_workers-1); i++)
    {
        start_index.push_back(i*len);
        end_index.push_back((i+1)*len-1);
    }
    start_index.push_back((num_of_workers-1)*len);
    end_index.push_back(num_of_index-1);
    
if( mxIsComplex(prhs[0]) )
    {
        if( mxIsSingle(prhs[0]) )
        {
            mxComplexSingle *spectrum, *Fkk;
            spectrum = mxGetComplexSingles(prhs[0]);  /* pointer for input spectrum */
            plhs[0] = mxCreateNumericMatrix(m_index, n_index, mxSINGLE_CLASS, mxCOMPLEX); /* Create an nr_dk-by-nc_k mxArray  */
            Fkk = mxGetComplexSingles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_csingle, start_index[i], end_index[i], index, spectrum, Fkk));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();      
        }
        else
        {
            mxComplexDouble *spectrum, *Fkk;
            spectrum = mxGetComplexDoubles(prhs[0]);
            plhs[0] = mxCreateNumericMatrix(m_index, n_index, mxDOUBLE_CLASS, mxCOMPLEX);
            Fkk = mxGetComplexDoubles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_cdouble, start_index[i], end_index[i], index, spectrum, Fkk));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();                     
        }
    }
    else
    {
        if( mxIsSingle(prhs[0]) )
        {
            mxSingle *spectrum, *Fkk;
            spectrum = mxGetSingles(prhs[0]);  /* pointer for input spectrum */
            plhs[0] = mxCreateNumericMatrix(m_index, n_index, mxSINGLE_CLASS, mxREAL); /* Create an nr_dk-by-nc_k mxArray  */
            Fkk = mxGetSingles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_single, start_index[i], end_index[i], index, spectrum, Fkk));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();            
        }
        else
        {
            mxDouble *spectrum, *Fkk;
            spectrum = mxGetDoubles(prhs[0]);
            plhs[0] = mxCreateNumericMatrix(m_index, n_index, mxDOUBLE_CLASS, mxREAL);
            Fkk = mxGetDoubles(plhs[0]);
            for (mwSize i = 0; i < num_of_workers; i++)
                workers.push_back(thread(worker_double, start_index[i], end_index[i], index, spectrum, Fkk));
            for (mwSize i = 0; i < num_of_workers; i++)
                workers[i].join();               
        }        
    }
}

void errorChk(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /* check for the proper number of arguments */
    if(nrhs != 2)
        mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:invalidNumInputs", "Four inputs required.");
    
    if(nlhs > 1)
        mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:maxlhs", "Too many output arguments.");
    
    if( !(mxIsDouble(prhs[0]) || mxIsSingle(prhs[0])) )
        mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:inputNotDoubleorSingleArray", "input array must be a double or single.");
        
    if( !mxIsInt64(prhs[1]) )
        mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:inputNot1DDoubleArray", "The input index must be an Int64 type array.");
    
    mwSize *index = (mwSize *)mxGetInt64s(prhs[1]);
    mwSize m_index = mxGetM(prhs[1]);           /* number of rows of index array */            
    mwSize n_index = mxGetN(prhs[1]);           /* number of columns of index array */
    mwSize num_of_index = n_index*m_index;
    
    mwSize m_dk = mxGetM(prhs[0]);                     /* num of columns of spectrum */
    mwSize n_dk = mxGetN(prhs[0]);                     /* num of columns of spectrum */
    mwSize num_of_dks = m_dk*n_dk;
    for (mwSize i = 0; i < num_of_index; i++){
        if( (index[i] <= 0) || (index[i] > num_of_dks) ){
            mexErrMsgIdAndTxt( "MATLAB:indexing_array_mt:indexOutofRange", "index exceeds valid range.");
        }
    }
}

void worker_csingle(mwSize start, mwSize end, mwSize* index, mxComplexSingle* spectrum, mxComplexSingle* Fkk) 
{
    for (mwSize i = start; i <= end; i++)
        Fkk[i] = spectrum[index[i]-1];
}
void worker_cdouble(mwSize start, mwSize end, mwSize* index, mxComplexDouble* spectrum, mxComplexDouble* Fkk) 
{
    for (mwSize i = start; i <= end; i++)
        Fkk[i] = spectrum[index[i]-1];
}
void worker_single(mwSize start, mwSize end, mwSize* index, mxSingle* spectrum, mxSingle* Fkk) 
{
    for (mwSize i = start; i <= end; i++)
        Fkk[i] = spectrum[index[i]-1];
}
void worker_double(mwSize start, mwSize end, mwSize* index, mxDouble* spectrum, mxDouble* Fkk) 
{
    for (mwSize i = start; i <= end; i++)
        Fkk[i] = spectrum[index[i]-1];
}
