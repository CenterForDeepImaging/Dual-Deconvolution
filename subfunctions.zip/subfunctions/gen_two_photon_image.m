function [tp_image] = gen_two_photon_image(psim_data, precision)
    % This function processes the cam_images field in the input psim_data
    % structure to generate a two-photon excitation image. It integrates
    % the pixel intensities of the image stack along the X and Y dimensions,
    % and reshapes the resulting vector to form the final 2D image.
    %
    % Inputs:
    %   psim_data - A structure containing:
    %       cam_images - A 3D stack of raw images acquired during scanning.
    %       scan_info  - A structure containing scanning information, such as:
    %           N_scan_points - The number of scan points along one dimension.
    %   precision - The numeric precision to cast cam_images to ('single' or 'double').
    %
    % Outputs:
    %   tp_image - A 2D two-photon excitation image (N_scan_points x N_scan_points).

disp('Generate conventional two-photon excitation image ...');

tp_image = cast(psim_data.cam_images, precision);
tp_image = squeeze(sum(sum(tp_image,1),2));
tp_image = reshape(tp_image, psim_data.scan_info.N_scan_points, psim_data.scan_info.N_scan_points);

disp('Done.');