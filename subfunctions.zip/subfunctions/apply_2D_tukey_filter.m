function filtered_img = apply_2D_tukey_filter(img, tukey_param)

N_img = size(img,1);
twin = tukeywin(N_img, tukey_param);
twin = cast(twin, class(img));
twin2D = repmat(twin, 1, N_img)*repmat(twin', N_img,1);
filtered_img = img.*twin2D;

end