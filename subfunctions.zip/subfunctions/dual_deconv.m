function [AOSIM_image, H_ex_map, H_em_map] = dual_deconv(Fkk, otf_params, params)
%
% Copyright (c) 2024 Seokchan Yoon
% 
% This software is released under the MIT License.
% https://opensource.org/licenses/MIT
%

% -------- Initialize parameters ---------------
disp('Initializing parameters ...');

precision = class(Fkk);
params.iter_tol = cast(params.iter_tol, precision);
params.alpha = cast(params.alpha, precision);
params.beta = cast(params.beta, precision);
params.gamma = cast(params.gamma, precision);
params.gamma = cast(params.gamma, precision);

N_otf_ex = size(otf_params.kin_mask,1); 
N_otf_em = size(otf_params.kout_mask,1);

kex_index = find(otf_params.kin_mask)';
kem_index = find(otf_params.kout_mask)';
kex_c = sub2ind([N_otf_ex, N_otf_ex], N_otf_ex/2+1, N_otf_ex/2+1);
kex_c = find(kex_index == kex_c);
kem_c = sub2ind([N_otf_em, N_otf_em], N_otf_em/2+1, N_otf_em/2+1);
kem_c = find(kem_index == kem_c);

%  Generate index_dk 
[index_dk, N_conv] = index_for_synthesis(otf_params.kin_mask, otf_params.kout_mask);
dk_c = sub2ind([N_conv, N_conv], (N_conv+1)/2, (N_conv+1)/2);
num_of_dks = cast(N_conv^2, precision);

% Generate DC filter mask
DC_filter_mask = spectral_filter(N_conv, params.N_cutoff_k, N_conv, 1, precision);

% Check normalization 
if Fkk(kem_c, kex_c) ~= 1
    Fkk = Fkk/Fkk(kem_c, kex_c); 
end

% Create ideal (diffraction-limited) excitation and emission OTF maps
% Ideal excitation OTF, H_ex_ideal, 1-by-N_otf_ex row vector
Np = N_otf_ex/2;
[kx, ky] = meshgrid(1:Np, 1:Np);
kc = Np/2+1;
kr2 = (kx-kc).^2 + (ky-kc).^2;
pupil_func = (kr2 <= (Np/2)^2);
H_ex_ideal = cast(padarray(xcorr2(double(pupil_func)), [1, 1], 0, 'pre'), precision);
H_ex_ideal = H_ex_ideal(kex_index);
H_ex_ideal = H_ex_ideal./H_ex_ideal(kex_c); 

% Ideal emission OTF, H_em_ideal, N_otf_em-by-1 column vector
Np = N_otf_em/2;
[kx, ky] = meshgrid(1:Np, 1:Np);
kc = Np/2+1;
kr2 = (kx-kc).^2 + (ky-kc).^2;
pupil_func = (kr2 <= (Np/2)^2);
H_em_ideal = cast(padarray(xcorr2(double(pupil_func)), [1, 1], 0, 'pre'), precision);
H_em_ideal = H_em_ideal(kem_index)';
H_em_ideal = H_em_ideal./H_em_ideal(kem_c);

% -------- Prepare monitoring parameters and figures ---------------------- 
max_length = max(2, params.max_iter);
H_ex_err = nan(max_length, 1, precision);
H_em_err = nan(max_length, 1, precision);
iter_numbers = (1:max_length)';
h_fig = gen_figures(4);

% --------- Main loop for dual deconvolution ------------------------------
disp('Iteration begins ...');

% Initial guess for  excitation and emission OTFs, H_ex and H_em 
H_ex = H_ex_ideal.^3;   % Initial excitation OTF, H_ex(ki)
H_em = H_em_ideal.^3;   % Initial emission OTF, H_em(ko)

% Update object's spectrum, G(dk)
Hkk = H_em*H_ex;                                                % OTF matrix, H(ko,ki) = H_em(ko)*H_ex(ki)
Wkk = conj(Hkk)./(abs(Hkk).^2 + params.alpha.^2);               % Complex Wiener ilter matrix, W(ko,ki)
G_dk = accumarray_mex_mt(index_dk, Fkk.*Wkk, num_of_dks);       % Object spectrum, G(dk), obtained by synthesizing Gkk(ko,ki) = W(ko,ko).*F(ko,ki)
N_dk = accumarray_mex_mt(index_dk, abs(Wkk.*Hkk), num_of_dks);  % N(dk) is the convolved OTF after applying Winer filter matrix
N_dk = N_dk/N_dk(dk_c);
G_dk = spectrum_deconv(G_dk, N_dk, dk_c, params);   % Deconvolve the object's synthesized spectrum G(dk) by N(dk)

for iter=1:params.max_iter
    start_time = tic; 

    % ----- Update emission OTF, H_em(k) ------
    H_em_bef = H_em;
    Gkk_AC = reconstruct_Fkk_mex(conj(G_dk).*DC_filter_mask, index_dk); % DC filtered object's spectrum
    Gkk_AC = Gkk_AC.*H_ex;
    Gkk_norm = sum(abs(Gkk_AC).^2, 2);
    gamma = params.gamma*max(Gkk_norm);
    H_em = sum(Fkk.*Gkk_AC, 2).*(Gkk_norm./(Gkk_norm.^2 + gamma.^2));
    H_em = H_em/H_em(kem_c);
    % projection onto MTF constraint    
    MTF_em = abs(H_em);
    MTF_em = min(MTF_em, H_em_ideal);
    MTF_em = max(MTF_em, eps);
    H_em = MTF_em.*exp(1i*angle(H_em));  

    % ----- update object's spectrum, G(dk) ------
    Hkk = H_em*H_ex;
    Wkk = conj(Hkk)./(abs(Hkk).^2 + params.alpha.^2);
    G_dk = accumarray_mex_mt(index_dk, Fkk.*Wkk, num_of_dks);
    N_dk = accumarray_mex_mt(index_dk, abs(Wkk.*Hkk), num_of_dks);
    G_dk = spectrum_deconv(G_dk, N_dk, dk_c, params);

    % ----- update excitation OTF, H_ex(k) ------
    H_ex_bef = H_ex;    
    Gkk_AC = reconstruct_Fkk_mex(conj(G_dk).*DC_filter_mask, index_dk); % Gkk_AC(k,k) is the DC-filtered object's spectrum matrix
    Gkk_AC = Gkk_AC.*H_em;
    Gkk_norm = sum(abs(Gkk_AC).^2, 1);
    gamma = params.gamma*max(Gkk_norm);
    H_ex = sum(Fkk.*Gkk_AC, 1).*(Gkk_norm./(Gkk_norm.^2 + gamma^2));
    H_ex = H_ex/H_ex(kex_c);
    % projection onto MTF constraint (the estimated MTF must be smaller than or equal to the ideal MTF)
    MTF_ex = abs(H_ex);
    MTF_ex = min(MTF_ex, H_ex_ideal);
    MTF_ex = max(MTF_ex, eps);
    H_ex = MTF_ex.*exp(1i*angle(H_ex));
    
    % ----- update object's spectrum, G(dk) ------
    Hkk = H_em*H_ex;
    Wkk = conj(Hkk)./(abs(Hkk).^2 + params.alpha.^2);
    G_dk = accumarray_mex_mt(index_dk, Fkk.*Wkk, num_of_dks);
    N_dk = accumarray_mex_mt(index_dk, abs(Wkk.*Hkk), num_of_dks);
    N_dk = N_dk/N_dk(dk_c);
    G_dk = spectrum_deconv(G_dk, N_dk, dk_c, params);
    
    % ----- reconstruct AO-SIM image by 2D Fourier transforming G(dk)
    AOSIM_image = spectrum_to_image(G_dk);   
    H_ex_map = otf_array_to_map(H_ex, kex_index, N_otf_ex);
    H_em_map = otf_array_to_map(H_em, kem_index, N_otf_em);

    % --- OTF errors for evaluating the iteration stopping criterion ---
    H_em_err(iter) = 1 - abs(mean(conj(H_em).*H_em_bef)/sqrt(mean(abs((H_em).^2)))/sqrt(mean(abs((H_em_bef).^2))));
    H_ex_err(iter) = 1 - abs(mean(conj(H_ex).*H_ex_bef)/sqrt(mean(abs((H_ex).^2)))/sqrt(mean(abs((H_ex_bef).^2))));

    elasped_time = toc(start_time);
    fprintf('%d iteration done. elasped time = %.3f second.\n',iter, double(elasped_time));

    % -------- draw monitoring figures ------------------
    draw_figures(h_fig, iter_numbers, H_ex_err, H_em_err, params.x_coord, params.y_coord, AOSIM_image, otf_params.otf_in, otf_params.otf_out, H_ex_map, H_em_map);
    
    % ---- check the iteration stopping criterion -------
    if (H_ex_err(iter)<params.iter_tol)&&(H_em_err(iter)<params.iter_tol), break; end
end

disp('Done.');
end

% -------------------------------------------------

