function Frr  = gen_Frr(psim_data, precision)
%
% Copyright (c) 2024 Seokchan Yoon
% 
% This software is released under the MIT License.
% https://opensource.org/licenses/MIT
%
% This function generates the incoherent response matrix, F(ro, ri),
% which represents the system's response in the lab coordinates, from
% the camera image stack after applying an optical transfer function (OTF) mask.
% The matrix F(ro, ri) is calculated by first applying the OTF mask and then
% transforming the descanned images from camera coordinates to lab coordinates.
%
% Inputs:
%   psim_data - A structure containing:
%       cam_images  - A 3D stack of camera images (N_cam x N_cam x N_images), where:
%                     N_images = N_xin^2.
%       otf_info    - A structure with OTF mask information.
%       scan_info   - A structure containing scan parameters, such as:
%   precision - The numeric precision to cast cam_images to ('single' or 'double').
%
% Outputs:
%   Frr - The incoherent response matrix, F(ro, ri), of size (N_xin x N_xin x N_images), where:
%         the images are scanned to transformed to match the lab coordinates.
%
% Notes:
%   - The camera images are assumed to be descanned images, and the function
%     uses indexing to convert the images from camera coordinates to lab coordinates.
%   - The matrix is computed using multi-threaded indexing with mex functions
%     (mex_indexing_array_mt and mex_crop_array_mt).

disp('Generate incoherent response matrix, F(ro,ri) ...');

% Cast camera images to the specified precision
cam_images = cast(psim_data.cam_images, precision);

% Apply OTF mask to the camera images
cam_images_pm = get_OTF_masked_images(cam_images, psim_data.otf_info); % Apply output OTF mask

% Extract image dimensions and scan information
N_xout = size(cam_images_pm, 1);
num_of_images = size(cam_images_pm, 3);
N_xin = psim_data.scan_info.N_scan_points;

% Calculate the indices for converting camera coordinates (F(ro-ri,ri)) to lab coordinates (F(ro,ri))
N0 = N_xin + N_xout - 1;
[y_in, x_in] = ind2sub([N_xin, N_xin], 1:psim_data.scan_info.N_tot_scan_points); % galvo-scanning order: uni-direction row majer scan
x_out = 0:(N_xout-1);
y_out = (0:(N_xout-1))';
dx = repmat(x_out + reshape(x_in, 1, 1, []), [N_xout 1 1]);
dx = reshape(dx, N_xout^2, []);
dy = repmat(y_out + reshape(y_in, 1, 1, []), [1 N_xout 1]);
dy = reshape(dy, N_xout^2, []);
indx = sub2ind([N0, N0], dy, dx);
clear dx dy;
indx = indx + N0^2*(0:(psim_data.scan_info.N_tot_scan_points-1));
indx = uint64(indx(:));

% Extract the response matrix F(ro, ri) using the indices
Frr = indexing_array_mex_mt(cam_images_pm, indx, N0^2, num_of_images);
Frr = reshape(Frr, N0, N0, []);

% Crop the matrix to the desired size (N_xin x N_xin) x N_xin^2
rs = N_xout/2 + 1;
re = N_xout/2 + N_xin;
Frr = crop_array_mex_mt(Frr, rs, re, rs, re);

disp('Done.');
end


%--------------------------------------------------------------------
function cam_images_pm = get_OTF_masked_images(cam_images, otf_info)
    % This function processes a stack of camera images by applying an optical
    % transfer function (OTF) mask in the Fourier domain. The function efficiently
    % handles memory-intensive operations by dividing the image stack into smaller
    % chunks if necessary, based on available CPU memory.
    %
    % Inputs:
    %   cam_images - A 3D stack of raw camera images (N_cam x N_cam x N_cam^2)
    %   otf_info   - A structure containing the OTF mask and relevant parameters.
    %
    % Outputs:
    %   cam_images_pm - A 3D stack of processed images with the OTF mask applied.
    %
mem_size = 1.5*(2+1)*get_memory_size(cam_images);
CPU_MAX_MEM = 0.9*cpu_avaible_memory();

if(mem_size<CPU_MAX_MEM)
    fft_images = fftshift(cam_images,1);
    fft_images = fftshift(fft_images,2);
    fft_images = fft2(fft_images);
    fft_images = ifftshift(fft_images,1);
    fft_images = ifftshift(fft_images,2);
    cam_images_pm = apply_otf_mask(fft_images, otf_info);
else
    cam_images_pm = [];
    num_of_images = size(cam_images,3);
    n_div = fix(mem_size/CPU_MAX_MEM);
    len = fix(num_of_images/(n_div+1));
    start_indx = 1;
    for n=1:n_div
        end_indx = start_indx+len-1;
        fft_images = fftshift(cam_images(:,:,start_indx:end_indx),1);
        fft_images = fftshift(fft_images,2);
        fft_images = fft2(fft_images);
        fft_images = ifftshift(fft_images,1);
        fft_images = ifftshift(fft_images,2);
        
        images_part = apply_otf_mask(fft_images, otf_info);
        cam_images_pm = cat(3, cam_images_pm, images_part);
        start_indx = end_indx + 1;
    end
    if start_indx<=num_of_images
        fft_images = fftshift(cam_images(:,:,start_indx:num_of_images),1);
        fft_images = fftshift(fft_images,2);
        fft_images = fft2(fft_images);
        fft_images = ifftshift(fft_images,1);
        fft_images = ifftshift(fft_images,2);  
        
        images_part = apply_otf_mask(fft_images, otf_info);
        cam_images_pm = cat(3, cam_images_pm, images_part);
    end
end

norm_factor = size(cam_images_pm,1)/size(cam_images,1);
precision = class(cam_images);
norm_factor = cast(norm_factor^2, precision);
cam_images_pm = cam_images_pm*norm_factor;

end

%--------------------------------------------------------------------
function  cam_images_pm = apply_otf_mask(fft_images, otf_info)

N_Kmax = otf_info.N_Kmax;
N_Kmax2 = N_Kmax/2;
N_cam = size(fft_images, 1);

if N_Kmax>N_cam
    N_pad = (N_Kmax - N_cam)/2;
    fft_images_pm = padarray(fft_images, [N_pad, N_pad], 0, 'both');
elseif N_Kmax<N_cam
    kc = N_cam/2 + 1;
    roi_k_start = kc - N_Kmax2;
    roi_k_end = kc + N_Kmax2-1;   
    fft_images_pm = mex_crop_array_mt(fft_images, roi_k_start, roi_k_end, roi_k_start, roi_k_end);
else
    fft_images_pm = fft_images;
end

% applying OTF mask
kmask = gen_pupil_mask(N_Kmax, 0, otf_info.N_otf_det);
data_type = class(fft_images_pm);
fft_images_pm = fft_images_pm.*cast(kmask, data_type);

fft_images_pm = ifftshift(fft_images_pm,1);
fft_images_pm = ifftshift(fft_images_pm,2);
cam_images_pm = ifft2(fft_images_pm, 'symmetric');
cam_images_pm = fftshift(cam_images_pm,1);
cam_images_pm = fftshift(cam_images_pm,2);

end
