function otf_map = otf_array_to_map(otf_array, p_index, p_size)

otf_map = zeros(p_size, p_size, class(otf_array));
otf_map(p_index) = otf_array;

end
