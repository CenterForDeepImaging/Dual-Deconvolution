function k_mask = gen_pupil_mask(n_size, kr_min, kr_max)

kc = n_size/2 + 1;
[kx, ky] = meshgrid(1:n_size, 1:n_size);
kr2 = (kx - kc).^2 + (ky - kc).^2;
kr_min2 = kr_min^2;
kr_max2 = kr_max^2;

k_mask = (kr2 >= kr_min2) & (kr2 <= kr_max2);

end