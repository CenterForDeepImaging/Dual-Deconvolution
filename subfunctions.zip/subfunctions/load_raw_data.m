function [psim_data] = load_raw_data(filename)
% Script for loading raw data (mat and binary files)

disp('Load raw data ...');

psim_data = load(filename, "-mat");
N_cam = psim_data.otf_info.N_cam;
N_tot_scan_points = psim_data.scan_info.N_tot_scan_points;

[FilePath, fname, ~] = fileparts(filename);
raw_data_filename = [FilePath, '/', fname, '.bin'];

fileID = fopen(raw_data_filename,'r');
psim_data.cam_images = fread(fileID,Inf,'*uint16');
psim_data.cam_images = reshape(psim_data.cam_images, N_cam, N_cam, N_tot_scan_points);

fclose(fileID);

disp('Done.');
