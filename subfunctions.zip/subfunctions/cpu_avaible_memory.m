function mem_avaible = cpu_avaible_memory()

if isunix
    [~, mem_avaible] = system('free -g | grep ^Mem | awk ''{print $4}''');
    mem_avaible = str2double(mem_avaible);
else
    GB = 2^30;
    user = memory;
    mem_avaible = user.MaxPossibleArrayBytes/GB;
end
