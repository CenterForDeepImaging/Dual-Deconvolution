function draw_figures(fig, iter_numbers, H_ex_err, H_em_err, x_coord, y_coord, AOSIM_image, OTF_in, OTF_out, H_ex_map, H_em_map)

if ishghandle(fig.handle)

    % draw AOSIM
    set(fig.AOSIM.axes, 'XLim', x_coord, 'YLim', y_coord);
    set(fig.AOSIM.plot, 'XData', x_coord, 'YData', y_coord, 'CData', AOSIM_image);
    fig.AOSIM.axes.DataAspectRatio = [1 1 1];
    green = flip(circshift(hot(256),1,2),2); % colormap
    colormap(fig.AOSIM.axes, green);
    colorbar(fig.AOSIM.axes);
    fig.AOSIM.axes.Title.String = 'AO-2PSIM image';
    % ylabel(fig.AOSIM.axes, 'y (\mum)');
    % xlabel(fig.AOSIM.axes, 'x (\mum)');
    fig.AOSIM.axes.Visible = 'on';

    % plot OTF errors
    set(fig.OTF_err.plot(1), 'XData', iter_numbers, 'YData', H_ex_err);
    set(fig.OTF_err.plot(2), 'XData', iter_numbers, 'YData', H_em_err);
    max_iter = max(length(iter_numbers), 2);
    fig.OTF_err.axes.XLim = [1 max_iter];
    fig.OTF_err.axes.XTick = 1:max_iter;
    pbaspect(fig.OTF_err.axes, [1 1 1]);
    fig.OTF_err.axes.Title.String = 'iteration monitor';
    fig.OTF_err.axes.Visible = 'on';

    % draw excitation PTF and MTF
    coords = [-OTF_in, OTF_in];
    set(fig.PTF_ex.axes, 'XLim', coords, 'YLim', coords);
    set(fig.PTF_ex.plot, 'XData', coords, 'YData', coords, 'CData', angle(H_ex_map));
    fig.PTF_ex.axes.DataAspectRatio = [1 1 1];
    colormap(fig.PTF_ex.axes, 'jet');
    colorbar(fig.PTF_ex.axes);
    fig.PTF_ex.axes.Title.String = 'excitation PTF';
    fig.PTF_ex.axes.Visible = 'on';

    set(fig.MTF_ex.axes, 'XLim', coords, 'YLim', coords);
    set(fig.MTF_ex.plot, 'XData', coords, 'YData', coords, 'CData', abs(H_ex_map));
    fig.MTF_ex.axes.DataAspectRatio = [1 1 1];
    colormap(fig.MTF_ex.axes, 'hot');
    colorbar(fig.MTF_ex.axes);
    fig.MTF_ex.axes.Title.String = 'excitation MTF';
    fig.MTF_ex.axes.Visible = 'on';

    % draw emission PTF and MTF
    coords = [-OTF_out, OTF_out];
    set(fig.PTF_em.axes, 'XLim', coords, 'YLim', coords);
    set(fig.PTF_em.plot, 'XData', coords, 'YData', coords, 'CData', angle(H_em_map));
    fig.PTF_em.axes.DataAspectRatio = [1 1 1];
    colormap(fig.PTF_em.axes, 'jet');
    colorbar(fig.PTF_em.axes);
    fig.PTF_em.axes.Title.String = 'emission PTF';
    fig.PTF_em.axes.Visible = 'on';

    set(fig.MTF_em.axes, 'XLim', coords, 'YLim', coords);
    set(fig.MTF_em.plot, 'XData', coords, 'YData', coords, 'CData', abs(H_em_map));
    fig.MTF_em.axes.DataAspectRatio = [1 1 1];
    colormap(fig.MTF_em.axes, 'hot');
    colorbar(fig.MTF_em.axes);
    fig.MTF_em.axes.Title.String = 'emission MTF';
    fig.MTF_em.axes.Visible = 'on';

    drawnow;

end