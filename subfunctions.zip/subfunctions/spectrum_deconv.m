function spec_deconv = spectrum_deconv(G_dk, N_dk, dk_c, params)
% spectrum_deconv performs spectral deconvolution to restore the spectrum.
%
% Inputs:
%   - G_dk: Observed spectrum, G(dk), provided as a 1D array.
%   - N_dk: System OTF in the frequency domain.
%   - dk_c: Index of the DC component in the spectrum.
%   - params: Struct containing deconvolution parameters:
%       - params.dec_type: Deconvolution type.
%                          true  -> Wiener filter with beta parameter.
%                          false -> Richardson-Lucy deconvolution.
%       - params.beta: Regularization parameter for Wiener filter.
%       - params.iterN_lucy: Number of iterations for Richardson-Lucy deconvolution.
%
% Outputs:
%   - spec_deconv: Deconvolved spectrum, normalized such that DC = 1.
%
% The function supports two deconvolution methods:
%   1. Wiener filter-based deconvolution (if params.dec_type is true).
%   2. Richardson-Lucy deconvolution (if params.dec_type is false).
%
% The deconvolved spectrum is normalized with respect to the DC component.

N_dk = N_dk/N_dk(dk_c);   % Normalize N_dk by its DC value
s_DC = G_dk(dk_c);        % Store the DC value of the observed spectrum

if params.dec_type  % Wiener filter-based deconvolution
    G = conj(N_dk)./(abs(N_dk).^2 + params.beta.^2);
    G = G/max(G);
    spec_deconv = G_dk.*G;    % Apply the Wiener filter to the observed spectrum
else                % Richardson-Lucy deconvolution
    img = spectrum_to_image(G_dk);                          % Convert spectrum to image (spatial domain)
    PSF = spectrum_to_image(N_dk);    
    img = deconvlucy(img, double(PSF), params.iterN_lucy);  % Perform Richardson-Lucy deconvolution
    spec_lucy = fftshift(fft2(fftshift(img)));              % Convert back to the frequency domain
    spec_lucy = spec_lucy(2:end, 2:end);
    spec_deconv = spec_lucy(:);
end

% Normalize the deconvolved spectrum with respect to the DC component
spec_deconv = (s_DC/spec_deconv(dk_c))*spec_deconv;

end