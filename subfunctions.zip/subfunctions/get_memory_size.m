function mem_size = get_memory_size(arr_in)

GB = 2^30;

get_varname = @(x) inputname(1);
varname = get_varname(arr_in);
mem_size = whos(varname).bytes/GB;

end
