function [F_ko_ki, otf_params] = gen_Fkk(psim_data, precision)
%
% Copyright (c) 2024 Seokchan Yoon
% 
% This software is released under the MIT License.
% https://opensource.org/licenses/MIT
%
% This function computes the k-space incoherent response matrix F(ko, ki) from the
% response matrix F(ro, ri). The process involves applying 2D Fourier Transforms,
% filtering, padding/cropping, and transposing the matrices to obtain the final
% F(ko, ki) matrix, which is normalized for correct scaling.
%
% Inputs:
%   psim_data - A structure containing:
%       cam_images  - A 3D stack of raw images acquired during scanning.
%       otf_info    - A structure containing camera-specific parameters
%       scan_info   - A structure containing scanning information
%   precision - The numerical precision (e.g., 'single' or 'double') for the computation.
%
% Outputs:
%   F_ko_ki   - The k-space incoherent response matrix F(ko, ki) of size N_Kmax^2 x N_Kmax^2.
%   otf_params - A structure containing the optical transfer function (OTF) parameters,
%                such as OTF size, masks ..

% Step 1: Generate F(ro, ri) matrix using gen_Frr function and apply 2D Tukey filter
F_ro_ri = gen_Frr(psim_data, precision);
F_ro_ri = apply_2D_tukey_filter(F_ro_ri, 0.08); % to remove ringing effect at the image edges

% Step 2: Set k-space parameters based on input scan and OTF info
disp('Convert F(ro,ri) to F(ko,ki), the k-space incoherent response matrix ...');
N_x = size(F_ro_ri, 1);
ratio = (N_x-1)/(psim_data.otf_info.N_Kmax-1);
otf_params.N_otf_in = round(ratio*psim_data.otf_info.N_otf_in);
otf_params.N_otf_out = round(ratio*psim_data.otf_info.N_otf_det);
otf_params.otf_in = psim_data.otf_info.otf_in;
otf_params.otf_out = psim_data.otf_info.otf_det;

N_2otf_in = 2*otf_params.N_otf_in + 1;
N_2otf_out = 2*otf_params.N_otf_out + 1;
N_Kmax = max(N_2otf_out + 1, N_2otf_in + 1);

N_otf_epsi = 0.05;
otf_params.kin_mask = gen_pupil_mask(N_Kmax, 0, (otf_params.N_otf_in+N_otf_epsi));
otf_params.kout_mask = gen_pupil_mask(N_Kmax, 0, (otf_params.N_otf_out+N_otf_epsi));

% Step 3: Perform 2D-FFT of F(ro, ri) along the ro direction to obtain F(ko, ri)
F_ko_ri = fft_output(F_ro_ri, true); clear Frr;

% Step 4: Padding or cropping of F(ko, ri) to match the required k-space dimensions
if N_x<N_Kmax
    N_pad = (N_Kmax-N_x)/2;
    F_ko_ri = padarray(F_ko_ri, [N_pad, N_pad], 0, 'both');
elseif N_x>N_Kmax
    N_crop = (N_x-N_Kmax)/2;
    crop_roi = (N_crop+1):(N_x-N_crop);
    F_ko_ri = F_ko_ri(crop_roi,crop_roi,:);
end

% Step 5: Transpose F(ko, ri) to F(ri, ko)
F_ko_ri = reshape(F_ko_ri, N_Kmax^2, []);
F_ko_ri = F_ko_ri(otf_params.kout_mask(:), :);
F_ri_ko = F_ko_ri.';  clear F_ko_ri;
F_ri_ko = reshape(F_ri_ko, N_x, N_x, []);
F_ri_ko = apply_2D_tukey_filter(F_ri_ko, 0.08); % to remove ringing effect at the image edges

% Step 6: Perform 2D-FFT of F(ri, ki) along the ri direction to obtain F(ki, ko)
F_ki_ko = fft_output(F_ri_ko, true); clear F_ri_ko;

% Step 7: Padding or cropping of F(ki, ko) to match the required k-space dimensions
if N_x<N_Kmax
    F_ki_ko = padarray(F_ki_ko, [N_pad, N_pad], 0, 'both');
elseif N_x>N_Kmax
    F_ki_ko = F_ki_ko(crop_roi,crop_roi,:);
end

% Step 8: Transpose F(ki, ko) to F(ko, ki)
F_ki_ko = reshape(F_ki_ko, N_Kmax^2, []);
F_ki_ko = F_ki_ko(otf_params.kin_mask(:), :);
F_ko_ki = F_ki_ko.';

% Step 9: Normalize F(ko, ki) by the DC spectral component to 1
kc = sub2ind([N_Kmax, N_Kmax], N_Kmax/2+1, N_Kmax/2+1);
kin_index = find(otf_params.kin_mask);
kin_c = find(kin_index == kc);
kout_index = find(otf_params.kout_mask);
kout_c = find(kout_index == kc);
F_ko_ki = F_ko_ki/F_ko_ki(kout_c, kin_c);

disp('Done.');
end

%------------------------------------------------------
function Fkr = fft_output(Frr, fft_direction)
% Perform FFT (if fft_direction is true) or IFFT (if fft_direction is false) 
% on the input matrix Frr. The function supports both full image processing and 
% memory-efficient processing by dividing the data into smaller chunks when 
% the memory size exceeds the available system memor
%
% Input:
%   - Frr: The input matrix (F(ro,ri)) to be transformed.
%   - fft_direction: Boolean flag that determines the direction of the transform.
%     - true  -> FFT (Forward Transform)
%     - false -> IFFT (Inverse Transform)

% Output:
%   - Fkr: The output matrix after FFT or IFFT transformation.

[~, ~, num_of_images] = size(Frr);  % Get the dimensions of the input matrix
mem_size = 3*get_memory_size(Frr);  % Estimate the memory required for the FFT operation
max_mem = 0.9*cpu_avaible_memory(); % Max available memory (90% of the system memory)

% If the memory required for FFT is less than the available memory, perform the operation on the full dataset
if mem_size<max_mem   
    Fkr = fftshift(Frr, 1);
    Fkr = fftshift(Fkr, 2);
    if fft_direction
        Fkr = fft2(Fkr);  % Perform FFT if fft_direction is true
    else 
        Fkr = ifft2(Fkr); % Perform IFFT if fft_direction is false
    end
else  
    % If the memory required exceeds available memory, process the data in smaller chunks
    n_div = fix(mem_size/max_mem);        % Divide the data into smaller chunks
    len = fix(num_of_images/(n_div+1));   % Calculate the length of each chunk
    start_indx = 1;                       % Initialize the starting index for chunking

    Fkr = zeros(size(Frr), 'like', Frr);  % Initialize Fkr
    
    % Loop over the chunks and perform FFT or IFFT on each part
    for n=1:n_div
        end_indx = start_indx+len-1;
        Frr_chunk = fftshift(Frr(:,:,start_indx:end_indx),1);
        Frr_chunk = fftshift(Frr_chunk, 2);
        if fft_direction
            Fkr_chunk = fft2(Frr_chunk);
        else
            Fkr_chunk = ifft2(Frr_chunk);
        end
        Fkr(:,:,start_indx:end_indx) = Fkr_chunk;
        start_indx = end_indx + 1;
    end

    % If there are remaining images, process them
    if start_indx<=num_of_images
        Frr_chunk = fftshift(Frr(:,:,start_indx:end_indx),1);
        Frr_chunk = fftshift(Frr_chunk, 2);        
        if fft_direction
            Fkr_chunk = fft2(Frr_chunk);
        else
            Fkr_chunk =ifft2(Frr_chunk);
        end
       Fkr(:,:,start_indx:num_of_images) = Fkr_chunk;
    end
end

% Final shift to center the frequency components
Fkr = fftshift(Fkr, 1);
Fkr = fftshift(Fkr, 2);

end


